var goods = require('../models/Quen_mat_khau');


exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};

