var goods = require('../models/don_hang');

exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};