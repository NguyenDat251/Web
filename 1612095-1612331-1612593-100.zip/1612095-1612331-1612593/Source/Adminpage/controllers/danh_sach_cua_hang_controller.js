var goods = require('../models/danh_sach_cua_hang');

exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};