var goods = require('../models/Sua_thong_tin');


exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};

