var goods = require('../models/Cua_hang');


exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};

