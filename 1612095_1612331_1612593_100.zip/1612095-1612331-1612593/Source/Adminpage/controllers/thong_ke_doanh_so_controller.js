var goods = require('../models/thong_ke_doanh_so');

exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};