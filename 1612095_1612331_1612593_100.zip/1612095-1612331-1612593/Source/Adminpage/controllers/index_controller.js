var goods = require('../models/index');

exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};