var goods = require('../models/thay_doi_thong_tin');

exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};