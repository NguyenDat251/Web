var goods = require('../models/danh_sach_cho_duyet');


exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};

