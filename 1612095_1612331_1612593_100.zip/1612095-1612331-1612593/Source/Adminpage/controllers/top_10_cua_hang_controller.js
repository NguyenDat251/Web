var goods = require('../models/top_10_cua_hang');

exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};