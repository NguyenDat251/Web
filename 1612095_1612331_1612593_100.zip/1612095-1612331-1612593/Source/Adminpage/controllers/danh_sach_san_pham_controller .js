var goods = require('../models/danh_sach_san_pham');

exports.show_list = function(req, res) {
    res.send('NOT IMPLEMENTED: most favorite goods list');
};